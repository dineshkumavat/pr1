package com.starcast.management.starcastservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarcastServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StarcastServiceApplication.class, args);
	}

}
