package com.starcast.management.starcastservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StarcastServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
